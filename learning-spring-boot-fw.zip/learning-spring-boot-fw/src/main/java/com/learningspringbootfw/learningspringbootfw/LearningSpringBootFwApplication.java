package com.learningspringbootfw.learningspringbootfw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningSpringBootFwApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningSpringBootFwApplication.class, args);
	}

}
