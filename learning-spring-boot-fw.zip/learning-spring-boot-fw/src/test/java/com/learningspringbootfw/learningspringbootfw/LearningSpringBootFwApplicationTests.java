package com.learningspringbootfw.learningspringbootfw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningSpringBootFwApplicationTests {

	@Test
	void contextLoads() {
	}

}
